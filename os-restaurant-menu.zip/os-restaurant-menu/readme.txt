=== Plugin Name ===
Contributors: octaviansol
Donate link: 
Tags: food menu, restaurant menu
Requires at least: 3.1
Tested up to: 3.1
Stable tag: `/trunk/`

This plugin allows food menus management.

== Description ==

This plugin allows food menus management. This plugin works only with Genesis and its child themes.


== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Make sure you use Genesis framework

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==
No screenshots available at the moment

== Changelog ==

= 1.0 =
Only version

== Upgrade Notice ==

= 1.0 =
Plugin released